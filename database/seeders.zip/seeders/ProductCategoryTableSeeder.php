<?php

namespace Database\Seeders;

use App\Enums\Status;
use Illuminate\Support\Str;
use App\Models\ProductCategory;
use Illuminate\Database\Seeder;
use Dipokhalder\EnvEditor\EnvEditor;

class ProductCategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(): void
    {
        $envService = new EnvEditor();
        if ($envService->getValue('DEMO')) {

            $fashionCategories = [
                [
                    'name'       => [
                        'en' => 'Sunglasses',
                        'ar' => 'نظاره شمسيه',
                    ],
                    'description'       => [
                        'en' => 'Sunglasses Sunglasses',
                        'ar' => 'نظاره شمسيه',
                    ],
                    'slug'        => Str::slug('men'),
                    'image'       => 'image.png',
                    'status'      => Status::ACTIVE,
                    'created_at'  => now(),
                    'updated_at'  => now()
                ],
                [
                    'name'       => [
                        'en' => 'eyeglasses',
                        'ar' => 'نظارات طبيه',
                    ],
                    'description'       => [
                        'en' => 'eyeglasses eyeglasses',
                        'ar' => 'نظارات طبيه نظارات طبيه',
                    ],
                    'slug'        => Str::slug('women'),
                    'image'       => 'image.png',
                    'status'      => Status::ACTIVE,
                    'created_at'  => now(),
                    'updated_at'  => now()
                ]
            ];

            foreach ($fashionCategories as $fashionCategory) {
                $productCategory = ProductCategory::create($fashionCategory);
//                if (file_exists(public_path('/images/seeder/product-category/' . env('DISPLAY') . '/' . strtolower(str_replace(' ', '_', $fashionCategory['name'])) . '.png'))) {
//                    $productCategory->addMedia(public_path('/images/seeder/product-category/' . env('DISPLAY') . '/' . strtolower(str_replace(' ', '_', $fashionCategory['name'])) . '.png'))->preservingOriginal()->toMediaCollection('product-category');
//                }
            }
        }
    }
}
